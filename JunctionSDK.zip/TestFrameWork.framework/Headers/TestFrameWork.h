//
//  TestFrameWork.h
//  TestFrameWork
//
//  Created by Davit on 22.04.24.
//

#import <Foundation/Foundation.h>

//! Project version number for TestFrameWork.
FOUNDATION_EXPORT double TestFrameWorkVersionNumber;

//! Project version string for TestFrameWork.
FOUNDATION_EXPORT const unsigned char TestFrameWorkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFrameWork/PublicHeader.h>


